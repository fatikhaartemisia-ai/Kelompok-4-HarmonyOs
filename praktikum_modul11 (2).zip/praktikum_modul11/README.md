# Aplikasi Bank Sampah Organik & Penjualan Kompos Digital

Repositori ini berisi berkas dan dokumentasi praktikum **Basis Data – Modul 11: Teknologi DBMS, Penyimpanan JSON, dan Pemodelan Objek**.

## Identitas Mahasiswa Kelompok
1) Nama: Fakhriyatul Muzakkina (264311015): 1A 
2) Nama: Nashwa Nadia L. (264311023): 1A 
3) Nama: Fatikha Artemisia (264311016) : 1A 

- **Kelas:** TRPL 1A

## Struktur Berkas Proyek
- `modul11.sql` – Script SQL lengkap pembuatan database, 10 tabel relasional, pengisian data inti, operasi manipulasi atribut JSON, *generated column index*, serta pengujian transaksi ACID (`COMMIT` & `ROLLBACK`).
- `perbandingan_dbms.pdf` – Tabel perbandingan teknis dan analisis pemilihan DBMS (MySQL 8.x vs PostgreSQL vs MongoDB).
- `analisis_objek.pdf` – Analisis konsep pemodelan basis data berorientasi objek (*class*, *attribute*, *method*, *inheritance*) dan pemetaannya ke tabel relasional.
- `lingkup_penerapan.pdf` – Analisis permasalahan organisasi, kebutuhan data terstruktur/semi-terstruktur, serta fitur DBMS pada studi kasus Bank Sampah Organik.
- `pemodelan_objek.png` – Diagram kelas (*Class Diagram*) sistem pengguna dengan pewarisan (*inheritance*).
- `worksheet_modul11.pdf` – Dokumen laporan lembar kerja praktikum Modul 11 secara keseluruhan.
- `README.md` – Dokumentasi utama repositori proyek.

## Ringkasan Teknologi
- **DBMS:** MySQL 8.x (Storage Engine: `InnoDB`)
- **Pendekatan Model Data:** Hybrid (Relasional + Tipe Data `JSON` Native)
- **Fitur Utama:** *Foreign Key*, *CHECK Constraint* (aturan bisnis min. 3 kg, saldo mengendap Rp10.000, kode unik 6 digit), transaksi ACID, dan fungsi manipulasi JSON (`JSON_EXTRACT`, `JSON_SET`, `JSON_CONTAINS`, `JSON_REMOVE`).
