-- 03_data_awal.sql: Pengisian data inti
INSERT INTO wilayah_rtrw (id_wilayah, rt, rw, kelurahan, kecamatan) VALUES
(1, '01', '03', 'Sumbersari', 'Sejahtera'),
(2, '02', '03', 'Sumbersari', 'Sejahtera');

INSERT INTO users
(id_user, id_wilayah, nik, nama, no_hp, password_hash, peran, alamat,
 latitude, longitude, status_akun) VALUES
(1, NULL, NULL, 'Dewi Lestari', '081200000001',
 SHA2('admin12345', 256), 'admin', 'Kantor Bank Sampah Pusat',
 NULL, NULL, 'aktif'),
(2, 1, '3500000000000002', 'Bambang Hartono', '081200000002',
 SHA2('rt01pass', 256), 'ketua_rtrw', 'Jl. Melati No. 2',
 -7.6291000, 111.5231000, 'aktif'),
(3, 2, '3500000000000003', 'Slamet Riyadi', '081200000003',
 SHA2('rt02pass', 256), 'ketua_rtrw', 'Jl. Kenanga No. 7',
 -7.6342000, 111.5287000, 'aktif'),
(4, 1, '3500000000000004', 'Rina Wulandari', '081200000004',
 SHA2('rina12345', 256), 'nasabah', 'Jl. Melati No. 10',
 -7.6295000, 111.5236000, 'aktif'),
(5, 1, '3500000000000005', 'Siti Aminah', '081200000005',
 SHA2('siti12345', 256), 'nasabah', 'Jl. Melati No. 14',
 -7.6298000, 111.5240000, 'aktif'),
(6, 2, '3500000000000006', 'Agus Prasetyo', '081200000006',
 SHA2('agus12345', 256), 'nasabah', 'Jl. Kenanga No. 21',
 -7.6349000, 111.5293000, 'aktif'),
(7, NULL, '3500000000000007', 'Joko Santoso', '081200000007',
 SHA2('joko12345', 256), 'kurir', 'Jl. Mawar No. 3',
 NULL, NULL, 'aktif'),
(8, NULL, NULL, 'Sutrisno', '081200000008',
 SHA2('tani12345', 256), 'pembeli', 'Desa Sidomulyo',
 NULL, NULL, 'aktif'),
(9, NULL, NULL, 'Maya Kusuma', '081200000009',
 SHA2('maya12345', 256), 'pembeli', 'Jl. Anggrek No. 5',
 NULL, NULL, 'aktif'),
(10, 1, '3500000000000010', 'Hendra Kurniawan', '081200000010',
 SHA2('hendra123', 256), 'nasabah', 'Jl. Melati No. 18',
 -7.6301000, 111.5244000, 'menunggu');

INSERT INTO dompet_saldo (id_dompet, id_user, saldo_total, saldo_mengendap) VALUES
(1, 4, 11000, 10000),
(2, 5, 15000, 10000),
(3, 6,  5400, 10000);

INSERT INTO kategori_sampah
(id_kategori, nama_kategori, harga_bersih, harga_tercampur) VALUES
(1, 'Kotoran Ternak', 1500, 800),
(2, 'Sampah Kebun',   1000, 500),
(3, 'Sampah Dapur',   1200, 600);

INSERT INTO transaksi_jemput
(id_jemput, id_nasabah, id_kurir, tanggal_request, tanggal_jemput,
 estimasi_berat, status_jemput, total_rupiah) VALUES
(1, 4, 7, '2026-11-02 08:00:00', '2026-11-02 09:15:00', 15.00, 'selesai', 19000),
(2, 5, 7, '2026-11-03 07:30:00', '2026-11-03 08:40:00', 20.00, 'selesai', 30000),
(3, 6, 7, '2026-11-05 08:00:00', '2026-11-05 09:30:00', 10.00, 'selesai',  5400),
(4, 4, NULL, '2026-11-12 10:00:00', NULL,                3.50, 'menunggu',     0);

INSERT INTO detail_jemput
(id_detail, id_jemput, id_kategori, berat_aktual, status_pemilahan,
 harga_satuan, subtotal) VALUES
(1, 1, 3, 12.50, 'bersih',    1200, 15000),
(2, 1, 2,  8.00, 'tercampur',  500,  4000),
(3, 2, 1, 20.00, 'bersih',    1500, 30000),
(4, 3, 3,  9.00, 'tercampur',  600,  5400);

INSERT INTO penarikan_saldo
(id_penarikan, id_user, tanggal_pengajuan, jumlah, saldo_setelah,
 jenis_penarikan, kode_unik, status_penarikan) VALUES
(1, 5, '2026-11-06 10:00:00', 15000, 15000, 'online',  NULL,     'dicairkan'),
(2, 4, '2026-11-08 09:00:00',  8000, 11000, 'offline', '482915', 'dicairkan');

INSERT INTO stok_kompos (id_stok, nama_produk, harga_per_kg, stok_kg) VALUES
(1, 'Kompos Padat Curah', 3500, 40.00),
(2, 'Kompos Granul',      6000, 35.00);

INSERT INTO produksi_kompos
(id_produksi, id_stok, id_admin, berat_bahan_baku, tanggal_mulai,
 tanggal_panen, hasil_panen_kg, status_produksi) VALUES
(1, 1, 1, 100.00, '2026-10-01', '2026-10-30', 60.00, 'panen'),
(2, 1, 1, 150.00, '2026-11-05', NULL,          NULL, 'fermentasi'),
(3, 2, 1,  80.00, '2026-10-10', '2026-10-28', 40.00, 'panen');

INSERT INTO penjualan_kompos
(id_penjualan, id_stok, id_pembeli, tanggal_pesan, jumlah_kg,
 harga_satuan, total_bayar, status_pembayaran) VALUES
(1, 1, 8, '2026-11-04 10:00:00', 20.00, 3500, 70000, 'lunas'),
(2, 2, 9, '2026-11-06 14:00:00',  5.00, 6000, 30000, 'lunas'),
(3, 1, 8, '2026-11-13 09:00:00', 10.00, 3500, 35000, 'belum_lunas');

-- F.4 Mengisi Data dengan JSON
