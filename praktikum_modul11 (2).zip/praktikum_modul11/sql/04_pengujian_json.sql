-- 04_pengujian_json.sql: Pengujian JSON & Transaksi
ALTER TABLE users ADD COLUMN profil_tambahan JSON NULL AFTER status_akun;
UPDATE users SET profil_tambahan = '{"akses": ["master_harga", "verifikasi_akun", "produksi_kompos"]}' WHERE id_user = 1;
UPDATE users SET profil_tambahan = '{"masa_jabatan": "2025-2028"}' WHERE id_user = 2;
UPDATE users SET profil_tambahan = '{"masa_jabatan": "2025-2028"}' WHERE id_user = 3;
UPDATE users SET profil_tambahan = '{"anggota_keluarga": 4, "sumber_sampah": ["dapur"], "hari_jemput_favorit": "Sabtu"}' WHERE id_user = 4;
UPDATE users SET profil_tambahan = '{"anggota_keluarga": 3, "sumber_sampah": ["ternak", "kebun"], "jumlah_ternak": {"kambing": 6, "ayam": 20}}' WHERE id_user = 5;
UPDATE users SET profil_tambahan = '{"anggota_keluarga": 5, "sumber_sampah": ["dapur"]}' WHERE id_user = 6;
UPDATE users SET profil_tambahan = '{"kendaraan": "motor", "plat_nomor": "AE 4521 XY", "wilayah_tugas": ["RT 01/RW 03", "RT 02/RW 03"]}' WHERE id_user = 7;
UPDATE users SET profil_tambahan = '{"jenis_pembeli": "petani", "luas_lahan_m2": 10000, "komoditas": ["padi", "jagung"]}' WHERE id_user = 8;
UPDATE users SET profil_tambahan = '{"jenis_pembeli": "pehobi tanaman", "koleksi": "anggrek"}' WHERE id_user = 9;

ALTER TABLE kategori_sampah ADD COLUMN atribut JSON NULL;
UPDATE kategori_sampah SET atribut = '{"contoh": ["kotoran sapi", "kotoran kambing", "kotoran ayam"], "syarat": "kering angin, tidak tercampur tanah", "ditolak": ["plastik", "kaca", "bahan berbahaya"]}' WHERE id_kategori = 1;
UPDATE kategori_sampah SET atribut = '{"contoh": ["daun kering", "rumput", "ranting cacah"], "ukuran_maks_cm": 10, "ditolak": ["plastik", "kaca", "bahan berbahaya"]}' WHERE id_kategori = 2;
UPDATE kategori_sampah SET atribut = '{"contoh": ["sisa sayur", "kulit buah", "ampas kopi"], "syarat": "ditiriskan sebelum disetor", "ditolak": ["plastik", "kaca", "bahan berbahaya", "minyak jelantah"]}' WHERE id_kategori = 3;

ALTER TABLE detail_jemput ADD COLUMN catatan_pemilahan JSON NULL;
UPDATE detail_jemput SET catatan_pemilahan = '{"bahan_asing": [], "kondisi": "kering"}' WHERE id_detail = 1;
UPDATE detail_jemput SET catatan_pemilahan = '{"bahan_asing": ["plastik", "kaca"], "kondisi": "basah"}' WHERE id_detail = 2;
UPDATE detail_jemput SET catatan_pemilahan = '{"bahan_asing": [], "kondisi": "kering"}' WHERE id_detail = 3;
UPDATE detail_jemput SET catatan_pemilahan = '{"bahan_asing": ["plastik"], "kondisi": "basah", "tindakan": "dipilah ulang oleh kurir"}' WHERE id_detail = 4;

ALTER TABLE stok_kompos ADD COLUMN spesifikasi JSON NULL AFTER stok_kg;
UPDATE stok_kompos SET spesifikasi = '{"bentuk": "curah halus", "kemasan": "karung 25 kg", "kadar_air_persen": 35, "organik": true}' WHERE id_stok = 1;
UPDATE stok_kompos SET spesifikasi = '{"bentuk": "granul", "kemasan": "pouch 5 kg", "kadar_air_persen": 30, "organik": true, "rasio_c_n": "15:1"}' WHERE id_stok = 2;

ALTER TABLE produksi_kompos ADD COLUMN parameter_fermentasi JSON NULL;
UPDATE produksi_kompos SET parameter_fermentasi = '{"aktivator": "EM4", "suhu_rata_rata_c": 55, "pembalikan_kali": 6, "kelembapan_persen": 60}' WHERE id_produksi = 1;
UPDATE produksi_kompos SET parameter_fermentasi = '{"aktivator": "EM4", "suhu_rata_rata_c": 48, "pembalikan_kali": 2}' WHERE id_produksi = 2;
UPDATE produksi_kompos SET parameter_fermentasi = '{"aktivator": "Trichoderma", "suhu_rata_rata_c": 57, "pembalikan_kali": 7, "kelembapan_persen": 55, "pengayakan": "ayakan 10 mm"}' WHERE id_produksi = 3;

ALTER TABLE penarikan_saldo ADD COLUMN detail_penarikan JSON NULL;
UPDATE penarikan_saldo SET detail_penarikan = JSON_OBJECT('bank', 'BRI', 'no_rekening', '****4321', 'atas_nama', 'Siti Aminah', 'id_transfer', 'TRF-20261106-0001', 'status_transfer', 'berhasil') WHERE id_penarikan = 1;
UPDATE penarikan_saldo SET detail_penarikan = JSON_OBJECT('lokasi_pencairan', 'Pos RT 01', 'divalidasi_kurir', 'Joko Santoso', 'kode_terverifikasi', true) WHERE id_penarikan = 2;

-- F.5 - F.11 Operasi CRUD JSON & Index
SELECT nama, peran, JSON_EXTRACT(profil_tambahan, '$.kendaraan') AS kendaraan FROM users;
SELECT nama, alamat FROM users WHERE peran = 'nasabah' AND JSON_CONTAINS(profil_tambahan, '"ternak"', '$.sumber_sampah');

UPDATE stok_kompos SET spesifikasi = JSON_SET(spesifikasi, '$.kadar_air_persen', 32) WHERE nama_produk = 'Kompos Padat Curah';
UPDATE stok_kompos SET spesifikasi = JSON_SET(spesifikasi, '$.promo', 'Diskon 10% pembelian di atas 20 kg') WHERE nama_produk = 'Kompos Padat Curah';
UPDATE users SET profil_tambahan = JSON_ARRAY_APPEND(profil_tambahan, '$.sumber_sampah', 'kebun') WHERE nama = 'Rina Wulandari';

UPDATE stok_kompos SET spesifikasi = JSON_REMOVE(spesifikasi, '$.promo') WHERE nama_produk = 'Kompos Padat Curah';
UPDATE users SET profil_tambahan = JSON_REMOVE(profil_tambahan, '$.hari_jemput_favorit') WHERE nama = 'Rina Wulandari';

ALTER TABLE users
    ADD COLUMN jenis_pembeli VARCHAR(30)
        GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(profil_tambahan, '$.jenis_pembeli'))) VIRTUAL,
    ADD INDEX idx_users_jenis_pembeli (jenis_pembeli);

-- F.13 Pengujian Transaksi (COMMIT & ROLLBACK)
START TRANSACTION;
UPDATE stok_kompos SET stok_kg = stok_kg - 10 WHERE id_stok = 1;
UPDATE penjualan_kompos SET status_pembayaran = 'lunas' WHERE id_penjualan = 3;
ROLLBACK;

START TRANSACTION;
UPDATE dompet_saldo SET saldo_total = saldo_total - 5000 WHERE id_user = 5;
INSERT INTO penarikan_saldo (id_user, jumlah, saldo_setelah, jenis_penarikan, status_penarikan)
VALUES (5, 5000, 10000, 'online', 'diajukan');
COMMIT;
